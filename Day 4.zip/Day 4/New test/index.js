document.write("<br/>"+Number("3.14787868"));
document.write("<br/>"+Number(" ")); //The spce is zero
document.write("<br/>"+Number("")); //The null is zero
document.write("<br/>"+Number("99 88")); //The space is null

let num = 111;
let s=String(100+23);
document.write("<br/>"+String(num));
document.write("<br/>"+String(123));
document.write("<br/>"+String(s+100+23));
document.write("<br/>"+String("100"+"23")+String("100"+"23"));
